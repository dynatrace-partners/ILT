import logging
import paramiko
import requests
import io
import os
from ruxit.api.base_plugin import RemoteBasePlugin
from ruxit.api.exceptions import ConfigException

logger = logging.getLogger(__name__)


class Siebel_plugin(RemoteBasePlugin):

    seenAreas = set()

    def query(self, **kwargs):
        config = kwargs["config"]
        host = config["host"].strip()
        port = config["port"].strip()
        user = config["user"].strip()
        password = config["password"].strip()
        logPathHost = config["logPathHost"].strip()
        sarmquery = config["sarmquery"].strip()
        csvHostLocation = config["csvHostLocation"].strip()
        csvAGLocation = config["csvAGLocation"].strip()

        self.MINTLinesArr = []
        self.DT_URL = config["DT_URL"].strip()
        if self.DT_URL.endswith("/"):
            self.DT_URL = self.DT_URL[:-1]
        self.url = self.DT_URL + "/api/v2/metrics/ingest"
        self.DT_APITOKEN = config["DT_APITOKEN"].strip()
        self.DT_ENTITY = config["DT_ENTITY"].strip()

        logger.setLevel(logging.DEBUG)

        sarmAGCSV = csvAGLocation + "/sarm.csv"
        # Clean up old sarm.csv file if it exists
        if os.path.isfile(sarmAGCSV):
            logger.info("Old CSV file exists, deleting it")
            os.unlink(sarmAGCSV)

        # SSH to Siebel Host
        ssh_client = paramiko.SSHClient()
        ssh_client.load_system_host_keys()
        ssh_client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        ssh_client.connect(hostname=host, port=port, username=user, password=password)

        sarmHostCSV = csvHostLocation + "/sarm.csv"
        logger.info("Siebel Host Location for sarmCSV = " + sarmHostCSV)

        # Execute sarmquery command on remote Siebel Host
        sarmqueryCMD = sarmquery + " -input " + logPathHost + " -output sarm=" + sarmHostCSV + " -select starttime=-120 -select endtime=-60"
        ssh_client.exec_command(command=sarmqueryCMD, timeout=20)

        # close ssh connection after running command
        ssh_client.close()

        # Parse SARM csv
        columns = {'Dynamic HdrID': 0,
                   'Start Time': 1,
                   'End Time': 2,
                   'SarmID': 3,
                   'SearchID': 4,
                   'ParentID': 5,
                   'RootID': 6,
                   'ThreadID': 7,
                   'TaskID': 8,
                   'Depth': 9,
                   'Level': 10,
                   'Area': 11,
                   'SubArea': 12,
                   'Repeat Count': 13,
                   'RespTime(ms)': 14,
                   '%Self Time': 15,
                   '%CPU': 16,
                   'CpuTime(ms)': 17,
                   'System Mem(bytes)': 18,
                   'Self RespTime(ms)': 19,
                   'Self CpuTime(ms)': 20,
                   'Self System Mem(bytes)': 21,
                   '# Pruned Decendants': 22,
                   'Total Pruned Duration(ms)': 23,
                   '# Sys Mem Calls': 24,
                   'Pooled Mem(bytes)': 25,
                   '# Pool Mem Calls': 26,
                   'Instance Name': 27,
                   'Detail': 28,
                   'IntArg1': 29,
                   'IntArg2': 30,
                   'User': 31,
                   'SessionId': 32,
                   'CorrelationID': 33,
                   'ClickID': 34,
                   'Start Time(utc)': 35,
                   'End Time(utc)': 36,
                   'Area(code)': 37,
                   'SubArea(code)': 38,
                   '# Descendants': 39,
                   '# Children': 40,
                   'Host Name': 41,
                   'Server Name': 42,
                   'Component Name': 43,
                   'File Name': 44}

        result = {
            "COM_INVOKE_METHOD": {"cnt": 0, "time": 0, "cpu": 0, "mem": 0, "splits": {}},
            "DBC_EXECUTE": {"cnt": 0, "time": 0, "cpu": 0, "mem": 0, "splits": {}},
            "DBC_FETCH": {"cnt": 0, "time": 0, "cpu": 0, "mem":  0, "splits": {}},
            "DBC_PREPARE": {"cnt": 0, "time": 0, "cpu": 0, "mem":  0, "splits": {}},
            "DBC_WRITE": {"cnt": 0, "time": 0, "cpu": 0, "mem":  0, "splits": {}},
            "EAITRANSP_TRANSPORT_SEND_RECEIVE": {"cnt": 0, "time": 0, "cpu": 0, "mem":  0, "splits": {}},
            "FSM_SENDREQ": {"cnt": 0, "time": 0, "cpu": 0, "mem":  0, "splits": {}},
            "SCRIPT_B_EXECUTE_EVENT": {"cnt": 0, "time": 0, "cpu": 0, "mem":  0, "splits": {}},
            "SCRIPT_J_EXECUTE_EVENT": {"cnt": 0, "time": 0, "cpu": 0, "mem":  0, "splits": {}},
            "SRB_ASYNCMSG": {"cnt": 0, "time": 0, "cpu": 0, "mem":  0, "splits": {}},
            "SRB_SYNCMSG": {"cnt": 0, "time": 0, "cpu": 0, "mem":  0, "splits": {}},
            "SRM_COMPSHELL": {"cnt": 0, "time": 0, "cpu": 0, "mem":  0, "splits": {}},
            "WORKFLOW_CORDR_EXECUTE": {"cnt": 0, "time": 0, "cpu": 0, "mem":  0, "splits": {}},
            "WORKFLOW_ENGNE_INVOKE": {"cnt": 0, "time": 0, "cpu": 0, "mem":  0, "splits": {}},
            "SARM_IO": {"cnt": 0, "time": 0, "cpu": 0, "mem":  0, "splits": {}},
            "SWSE_COMPRESS": {"cnt": 0, "time": 0, "cpu": 0, "mem":  0, "splits": {}},
            "SWSE_LOGIN": {"cnt": 0, "time": 0, "cpu": 0, "mem":  0},
            "SWSE_REQUEST": {"cnt": 0, "time": 0, "cpu": 0, "mem":  0, "splits": {}},
            "SWSE_SENDMSG": {"cnt": 0, "time": 0, "cpu": 0, "mem":  0, "splits": {}},
            "INFRA_CACHESTATS": {"cnt": 0, "time": 0, "cpu": 0, "mem":  0, "splits": {}},
            "INFRA_ENTRY": {"cnt": 0, "time": 0, "cpu": 0, "mem":  0},
            "OBJMGR_SESS_LOGIN": {"cnt": 0, "time": 0, "cpu": 0, "mem":  0},
            "SWE_CMD_SWEUAID": {"cnt": 0, "time": 0, "cpu": 0, "mem":  0},
            "SWEPAGE_APPLET_BUILD": {"cnt": 0, "time": 0, "cpu": 0, "mem":  0, "splits": {}},
            "SWEPAGE_APPLET_SHOW": {"cnt": 0, "time": 0, "cpu": 0, "mem":  0, "splits": {}},
            "SWEPAGE_VIEW_BUILD": {"cnt": 0, "time": 0, "cpu": 0, "mem":  0, "splits": {}},
            "SWEPAGE_VIEW_LAYOUT": {"cnt": 0, "time": 0, "cpu": 0, "mem":  0, "splits": {}},
            "SWEPAGE_VIEW_SHOW": {"cnt": 0, "time": 0, "cpu": 0, "mem":  0, "splits": {}},
            "OTHER": {"cnt": 0, "time": 0, "cpu": 0, "mem":  0, "splits": {}}
        }

        with io.open(sarmAGCSV, "r", encoding="utf-8") as sarmlog:
            for line in sarmlog:
                logEntry = line.split(',')
                if logEntry[columns["Level"]].strip() == "Sarm(1)":
                    subArea = logEntry[columns["SubArea"]].strip()
                    time = float(logEntry[columns["RespTime(ms)"]])
                    cpu = float(logEntry[columns["CpuTime(ms)"]])
                    mem = float(logEntry[columns["Pooled Mem(bytes)"]])
                    if mem < 0:
                        mem = 0
                    if subArea in result:
                        instanceName = logEntry[columns["Instance Name"]].strip()
                    else:
                        logger.warn(f"{subArea} not defined, adding to 'OTHER'")
                        instanceName = subArea
                        subArea = "OTHER"
                    result[subArea]["cnt"] += 1
                    result[subArea]["time"] += time
                    result[subArea]["cpu"] += cpu
                    result[subArea]["mem"] += mem
                    if instanceName != "" and "splits" in result[subArea]:
                        if instanceName not in result[subArea]["splits"]:
                            result[subArea]["splits"][instanceName] = {"cnt": 1, "time": time, "cpu": cpu, "mem": mem}
                        else:
                            result[subArea]["splits"][instanceName]["cnt"] += 1
                            result[subArea]["splits"][instanceName]["time"] += time
                            result[subArea]["splits"][instanceName]["cpu"] += cpu
                            result[subArea]["splits"][instanceName]["mem"] += mem

        for area in result:
            if "splits" not in result[area]:
                result[area]["splits"] = {}
            if len(result[area]["splits"]) == 0:
                result[area]["splits"]["Total"] = {"cnt": result[area]["cnt"], "time": result[area]["time"], "cpu": result[area]["cpu"], "mem": result[area]["mem"]}
            for split in result[area]["splits"]:
                if result[area]["splits"][split]["cnt"] > 0:
                    self.seenAreas.add(area)
                if area in self.seenAreas:
                    MINTLine = "tech.siebel." + area + ".cnt,dt.entity.host=\"" + self.DT_ENTITY + "\",instance=\"" + split + "\" gauge," + str(result[area]["splits"][split]["cnt"])
                    self.MINTLinesArr.append(MINTLine)
                    # self.results_builder.add_absolute_result(PluginMeasurement(key=area+".cnt", value=result[area]["splits"][split]["cnt"], dimensions={"Instance": split}, entity_selector=HostSelector()))
                    if result[area]["splits"][split]["cnt"] > 0:
                        # self.results_builder.add_absolute_result(
                        # PluginMeasurement(key=area+".time", value=result[area]["splits"][split]["time"] / result[area]["splits"][split]["cnt"], dimensions={"Instance": split}, entity_selector=HostSelector()))
                        MINTLine = "tech.siebel." + area + ".time,dt.entity.host=\"" + self.DT_ENTITY + "\",instance=\"" + split + "\" gauge," + str(result[area]["splits"][split]["time"] / result[area]["splits"][split]["cnt"])
                        self.MINTLinesArr.append(MINTLine)
                        # self.results_builder.add_absolute_result(PluginMeasurement(key=area+".cpu", value=result[area]["splits"][split]["cpu"], dimensions={"Instance": split}, entity_selector=HostSelector()))
                        MINTLine = "tech.siebel." + area + ".cpu,dt.entity.host=\"" + self.DT_ENTITY + "\",instance=\"" + split + "\" gauge," + str(result[area]["splits"][split]["cpu"])
                        self.MINTLinesArr.append(MINTLine)
                        # self.results_builder.add_absolute_result(PluginMeasurement(key=area+".mem", value=result[area]["splits"][split]["mem"], dimensions={"Instance": split}, entity_selector=HostSelector()))
                        MINTLine = "tech.siebel." + area + ".mem,dt.entity.host=\"" + self.DT_ENTITY + "\",instance=\"" + split + "\" gauge," + str(result[area]["splits"][split]["mem"])
                        self.MINTLinesArr.append(MINTLine)

        self.sendToMint(self.MINTLinesArr)

    def sendToMint(self, MINTLinesArr):
        logger.debug('Send Metrics to MINT : ')
        logger.debug(MINTLinesArr)
        HEADERS = {'Content-Type': 'text/plain'}
        PARAMS = {'api-token': self.DT_APITOKEN}
        numMINTLines = len(MINTLinesArr)
        if numMINTLines > 0:
            if numMINTLines < 1000:
                payload = ""
                for line in MINTLinesArr:
                    payload = payload + line + "\n"
                try:
                    response = requests.post(self.url, data=payload, headers=HEADERS, params=PARAMS)
                except Exception as e:
                    logger.exception(str(e))
                    raise ConfigException("Unable to POST Data to URL")
                logger.info(response.text)
            else:
                payload = ""
                index = 0
                for line in MINTLinesArr:
                    payload = payload + line + "\n"
                    index += 1
                    if index % 1000 == 0:
                        try:
                            response = requests.post(self.url, data=payload, headers=HEADERS, params=PARAMS)
                        except Exception as e:
                            logger.exception(str(e))
                            raise ConfigException("Unable to POST Data to URL")
                        logger.info(response.text)
                        index = 0
