import logging
import csv
import os
import subprocess
import tempfile
import io
from ruxit.api.base_plugin import BasePlugin
from ruxit.api.selectors import HostSelector
from ruxit.api.data import PluginMeasurement

logger = logging.getLogger(__name__)

class Siebel_plugin(BasePlugin):

    seenAreas = set()

    def query(self, **kwargs):
        config = kwargs["config"]
        logPath = config["logPath"].strip()
        sarmquery = config["sarmquery"].strip()
        logPath = os.getenv(logPath, logPath)
        sarmquery = os.getenv(sarmquery, sarmquery)
        
        # Run sarmquery to generate the csv file
        sarmFolder = tempfile.gettempdir() + "/siebel_plugin"
        if not os.path.exists(sarmFolder):
            os.makedirs(sarmFolder)
        sarmCSV = sarmFolder + "/sarm.csv"
        
        logger.info("sarmCSV = " + sarmCSV)
        if os.path.isfile(sarmCSV):
            logger.info("CSV file exists, delete it")
            os.unlink(sarmCSV)
        if "LD_LIBRARY_PATH" in os.environ:
            ld_library_path = os.environ.get("LD_LIBRARY_PATH", "")
            if "/ucma/siebel/siebsrvr/SYBSsa90/lib" not in ld_library_path:
                os.environ["LD_LIBRARY_PATH"] = f"{os.environ['LD_LIBRARY_PATH']}:/ucma/siebel/siebsrvr/lib:/ucma/siebel/siebsrvr/lib/odbc/merant:/ucma/siebel/siebsrvr/mw/lib:/ucma/siebel/siebsrvr/SYBSsa90/lib:/usr/lib::/opt/oracle/product/12.2.0.1_32/lib"
        subprocess.run([sarmquery, "-input", logPath, "-output", "sarm=" + sarmCSV, "-select", "starttime=-120", "-select", "endtime=-60"])
        
        # Parse SARM csv
        columns = {'Dynamic HdrID':0,
                  'Start Time':1,
                  'End Time':2,
                  'SarmID':3,
                  'SearchID':4,
                  'ParentID':5,
                  'RootID':6,
                  'ThreadID':7,
                  'TaskID':8,
                  'Depth':9,
                  'Level':10,
                  'Area':11,
                  'SubArea':12,
                  'Repeat Count':13,
                  'RespTime(ms)':14,
                  '%Self Time':15,
                  '%CPU':16,
                  'CpuTime(ms)':17,
                  'System Mem(bytes)':18,
                  'Self RespTime(ms)':19,
                  'Self CpuTime(ms)':20,
                  'Self System Mem(bytes)':21,
                  '# Pruned Decendants':22,
                  'Total Pruned Duration(ms)':23,
                  '# Sys Mem Calls':24,
                  'Pooled Mem(bytes)':25,
                  '# Pool Mem Calls':26,
                  'Instance Name':27,
                  'Detail':28,
                  'IntArg1':29,
                  'IntArg2':30,
                  'User':31,
                  'SessionId':32,
                  'CorrelationID':33,
                  'ClickID':34,
                  'Start Time(utc)':35,
                  'End Time(utc)':36,
                  'Area(code)':37,
                  'SubArea(code)':38,
                  '# Descendants':39,
                  '# Children':40,
                  'Host Name':41,
                  'Server Name':42,
                  'Component Name':43,
                  'File Name':44}

        result = {
            "COM_INVOKE_METHOD":{"cnt":0, "time":0, "cpu":0, "mem": 0, "splits":{}},
            "DBC_EXECUTE":{"cnt":0, "time":0, "cpu":0, "mem": 0, "splits":{}},
            "DBC_FETCH":{"cnt":0, "time":0, "cpu":0, "mem": 0, "splits":{}},
            "DBC_PREPARE":{"cnt":0, "time":0, "cpu":0, "mem": 0, "splits":{}},
            "DBC_WRITE":{"cnt":0, "time":0, "cpu":0, "mem": 0, "splits":{}},
            "EAITRANSP_TRANSPORT_SEND_RECEIVE":{"cnt":0, "time":0, "cpu":0, "mem": 0, "splits":{}},
            "FSM_SENDREQ":{"cnt":0, "time":0, "cpu":0, "mem": 0, "splits":{}},
            "SCRIPT_B_EXECUTE_EVENT":{"cnt":0, "time":0, "cpu":0, "mem": 0, "splits":{}},
            "SCRIPT_J_EXECUTE_EVENT":{"cnt":0, "time":0, "cpu":0, "mem": 0, "splits":{}},
            "SRB_ASYNCMSG":{"cnt":0, "time":0, "cpu":0, "mem": 0, "splits":{}},
            "SRB_SYNCMSG":{"cnt":0, "time":0, "cpu":0, "mem": 0, "splits":{}},
            "SRM_COMPSHELL":{"cnt":0, "time":0, "cpu":0, "mem": 0, "splits":{}},
            "WORKFLOW_CORDR_EXECUTE":{"cnt":0, "time":0, "cpu":0, "mem": 0, "splits":{}},
            "WORKFLOW_ENGNE_INVOKE":{"cnt":0, "time":0, "cpu":0, "mem": 0, "splits":{}},
            "SARM_IO":{"cnt":0, "time":0, "cpu":0, "mem": 0, "splits":{}},
            "SWSE_COMPRESS":{"cnt":0, "time":0, "cpu":0, "mem": 0, "splits":{}},
            "SWSE_LOGIN":{"cnt":0, "time":0, "cpu":0, "mem": 0},
            "SWSE_REQUEST":{"cnt":0, "time":0, "cpu":0, "mem": 0, "splits":{}},
            "SWSE_SENDMSG":{"cnt":0, "time":0, "cpu":0, "mem": 0, "splits":{}},
            "INFRA_CACHESTATS":{"cnt":0, "time":0, "cpu":0, "mem": 0, "splits":{}},
            "INFRA_ENTRY":{"cnt":0, "time":0, "cpu":0, "mem": 0},
            "OBJMGR_SESS_LOGIN":{"cnt":0, "time":0, "cpu":0, "mem": 0},
            "SWE_CMD_SWEUAID":{"cnt":0, "time":0, "cpu":0, "mem": 0},
            "SWEPAGE_APPLET_BUILD":{"cnt":0, "time":0, "cpu":0, "mem": 0, "splits":{}},
            "SWEPAGE_APPLET_SHOW":{"cnt":0, "time":0, "cpu":0, "mem": 0, "splits":{}},
            "SWEPAGE_VIEW_BUILD":{"cnt":0, "time":0, "cpu":0, "mem": 0, "splits":{}},
            "SWEPAGE_VIEW_LAYOUT":{"cnt":0, "time":0, "cpu":0, "mem": 0, "splits":{}},
            "SWEPAGE_VIEW_SHOW":{"cnt":0, "time":0, "cpu":0, "mem": 0, "splits":{}},
            "OTHER":{"cnt":0, "time":0, "cpu":0, "mem": 0, "splits":{}}
        }
        
        with io.open(sarmCSV, "r", encoding="utf-8") as sarmlog:
            for line in sarmlog:
                logEntry = line.split(',')
                if logEntry[columns["Level"]].strip() == "Sarm(1)":
                    subArea = logEntry[columns["SubArea"]].strip()
                    time = float(logEntry[columns["RespTime(ms)"]])
                    cpu = float(logEntry[columns["CpuTime(ms)"]])
                    mem = float(logEntry[columns["Pooled Mem(bytes)"]])
                    if mem < 0:
                        mem = 0
                    if subArea in result:
                        instanceName = logEntry[columns["Instance Name"]].strip()
                    else:
                        logger.warn(f"{subArea} not defined, adding to 'OTHER'")
                        instanceName = subArea
                        subArea = "OTHER"
                    result[subArea]["cnt"] += 1
                    result[subArea]["time"] += time
                    result[subArea]["cpu"] += cpu
                    result[subArea]["mem"] += mem
                    if instanceName is not "" and "splits" in result[subArea]:
                        if instanceName not in result[subArea]["splits"]:
                            result[subArea]["splits"][instanceName] = {"cnt":1, "time": time, "cpu": cpu, "mem": mem}
                        else:
                            result[subArea]["splits"][instanceName]["cnt"] += 1
                            result[subArea]["splits"][instanceName]["time"] += time
                            result[subArea]["splits"][instanceName]["cpu"] += cpu
                            result[subArea]["splits"][instanceName]["mem"] += mem
        
        for area in result:
            if "splits" not in result[area]:
                result[area]["splits"] = {}
            if len(result[area]["splits"]) == 0:
                result[area]["splits"]["Total"] = {"cnt":result[area]["cnt"], "time":result[area]["time"], "cpu":result[area]["cpu"], "mem": result[area]["mem"]}
            for split in result[area]["splits"]:
                if result[area]["splits"][split]["cnt"] > 0:
                    self.seenAreas.add(area)
                if area in self.seenAreas:
                    self.results_builder.add_absolute_result(PluginMeasurement(key=area+".cnt", value=result[area]["splits"][split]["cnt"], dimensions={"Instance": split}, entity_selector=HostSelector()))
                    if result[area]["splits"][split]["cnt"] > 0:
                        self.results_builder.add_absolute_result(PluginMeasurement(key=area+".time", value=result[area]["splits"][split]["time"] / result[area]["splits"][split]["cnt"], dimensions={"Instance": split}, entity_selector=HostSelector()))
                        self.results_builder.add_absolute_result(PluginMeasurement(key=area+".cpu", value=result[area]["splits"][split]["cpu"], dimensions={"Instance": split}, entity_selector=HostSelector()))
                        self.results_builder.add_absolute_result(PluginMeasurement(key=area+".mem", value=result[area]["splits"][split]["mem"], dimensions={"Instance": split}, entity_selector=HostSelector()))